import sys
from datetime import datetime

# In-memory database
klanten = {}

# 5G abonnementen
abonnementen_5g = {
    "starter": {"snelheid": "300 Mbps", "datalimiet": "100 GB", "prijs": 30},
    "pro": {"snelheid": "800 Mbps", "datalimiet": "500 GB", "prijs": 50},
    "ultra": {"snelheid": "1.5 Gbps", "datalimiet": "Onbeperkt", "prijs": 75}
}

def voeg_klant_toe():
    klant_id = input("SIM ID / Klant-ID: ")
    naam = input("Naam: ")
    regio = input("Regio (bv. Amsterdam): ")
    klanten[klant_id] = {
        "naam": naam,
        "regio": regio,
        "abonnement": None,
        "verbruik_gb": 0,
        "aangemaakt": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    print(f"Klant '{naam}' in regio '{regio}' toegevoegd.\n")

def kies_abonnement():
    klant_id = input("SIM ID / Klant-ID: ")
    if klant_id not in klanten:
        print("Klant niet gevonden.\n")
        return

    print("Beschikbare 5G-abonnementen:")
    for naam, ab in abonnementen_5g.items():
        print(f"- {naam.capitalize()} | {ab['snelheid']} | {ab['datalimiet']} | €{ab['prijs']}/maand")

    keuze = input("Kies abonnement (starter/pro/ultra): ").lower()
    if keuze in abonnementen_5g:
        klanten[klant_id]["abonnement"] = keuze
        print("Abonnement ingesteld.\n")
    else:
        print("Ongeldige keuze.\n")

def update_verbruik():
    klant_id = input("SIM ID / Klant-ID: ")
    if klant_id not in klanten:
        print("Klant niet gevonden.\n")
        return

    try:
        gb = float(input("Voer verbruik in GB in: "))
        klanten[klant_id]["verbruik_gb"] += gb
        print("Verbruik bijgewerkt.\n")
    except ValueError:
        print("Ongeldige invoer.\n")

def toon_status():
    klant_id = input("SIM ID / Klant-ID: ")
    if klant_id not in klanten:
        print("Klant niet gevonden.\n")
        return

    klant = klanten[klant_id]
    ab = klant["abonnement"]
    print(f"""--- 5G STATUS ---
Naam: {klant['naam']}
Regio: {klant['regio']}
Abonnement: {ab or 'Geen'}
Snelheid: {abonnementen_5g[ab]['snelheid'] if ab else 'n.v.t.'}
Datalimiet: {abonnementen_5g[ab]['datalimiet'] if ab else 'n.v.t.'}
Verbruik: {klant['verbruik_gb']} GB
Aangemaakt op: {klant['aangemaakt']}
    """)

def hoofdmenu():
    while True:
        print("""======= 5G Internetprovider Console =======
1. Nieuwe klant (SIM) registreren
2. 5G-abonnement kiezen
3. Verbruik bijwerken (GB)
4. Status bekijken
5. Console afsluiten
        """)
        keuze = input("Maak een keuze (1-5): ")

        if keuze == "1":
            voeg_klant_toe()
        elif keuze == "2":
            kies_abonnement()
        elif keuze == "3":
            update_verbruik()
        elif keuze == "4":
            toon_status()
        elif keuze == "5":
            print("Console afgesloten.")
            sys.exit()
        else:
            print("Ongeldige keuze. Probeer opnieuw.\n")

if __name__ == "__main__":
    hoofdmenu()
